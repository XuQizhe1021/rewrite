"use strict";
(() => {
  // src/shared/config.ts
  function defaultProvider(providerId) {
    if (providerId === "deepseek") {
      return {
        providerId,
        apiKey: "",
        baseUrl: "https://api.deepseek.com",
        model: "deepseek-chat"
      };
    }
    if (providerId === "openai") {
      return {
        providerId,
        apiKey: "",
        baseUrl: "https://api.openai.com",
        model: "gpt-4o-mini"
      };
    }
    if (providerId === "anthropic") {
      return {
        providerId,
        apiKey: "",
        baseUrl: "https://api.anthropic.com",
        model: "claude-3-haiku-20240307"
      };
    }
    return {
      providerId,
      apiKey: "",
      baseUrl: "https://generativelanguage.googleapis.com",
      model: "gemini-1.5-flash"
    };
  }
  function defaultConfig() {
    return {
      provider: defaultProvider("deepseek"),
      temperature: 0.2,
      defaultMode: "summary",
      defaultStyle: "concise",
      defaultPresent: "sidepanel",
      auto: {
        enabled: false,
        domains: []
      }
    };
  }

  // src/ui/dom.ts
  function mustGetEl(id) {
    const el = document.getElementById(id);
    if (!el) throw new Error(`Missing element: #${id}`);
    return el;
  }
  function setText(el, text) {
    el.textContent = text;
  }

  // src/ui/port.ts
  function connectUiPort(onMessage) {
    const port2 = chrome.runtime.connect({ name: "ui" });
    port2.onMessage.addListener((m) => {
      onMessage(m);
    });
    return port2;
  }
  function postUi(port2, msg) {
    port2.postMessage(msg);
  }

  // src/options/index.ts
  var providerEl = mustGetEl("provider");
  var modelEl = mustGetEl("model");
  var baseUrlEl = mustGetEl("baseUrl");
  var apiKeyEl = mustGetEl("apiKey");
  var temperatureEl = mustGetEl("temperature");
  var defaultStyleEl = mustGetEl("defaultStyle");
  var defaultModeEl = mustGetEl("defaultMode");
  var defaultPresentEl = mustGetEl("defaultPresent");
  var saveBtn = mustGetEl("save");
  var resetBtn = mustGetEl("reset");
  var saveStatusEl = mustGetEl("saveStatus");
  var autoDomainEl = mustGetEl("autoDomain");
  var addDomainBtn = mustGetEl("addDomain");
  var domainListEl = mustGetEl("domainList");
  var config = defaultConfig();
  var port = connectUiPort((m) => {
    onBackgroundMessage(m);
  });
  postUi(port, { type: "UI_HELLO" });
  function normalizeDomain(input) {
    const s = input.trim().toLowerCase();
    if (!s) return null;
    const cleaned = s.replace(/^https?:\/\//, "").replace(/\/.+$/, "");
    if (!/^[a-z0-9.-]+$/.test(cleaned)) return null;
    if (!cleaned.includes(".")) return null;
    return cleaned;
  }
  function renderDomains() {
    domainListEl.innerHTML = "";
    for (const d of config.auto.domains) {
      const item = document.createElement("div");
      item.className = "ui-list-item";
      const left = document.createElement("div");
      left.innerHTML = `<code>${d}</code>`;
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "ui-btn";
      btn.textContent = "\u79FB\u9664";
      btn.addEventListener("click", async () => {
        const originPattern = `*://${d}/*`;
        await chrome.permissions.remove({ origins: [originPattern] });
        config = {
          ...config,
          auto: {
            ...config.auto,
            domains: config.auto.domains.filter((x) => x !== d)
          }
        };
        await persist();
        renderDomains();
      });
      item.append(left, btn);
      domainListEl.appendChild(item);
    }
  }
  function applyToForm() {
    providerEl.value = config.provider.providerId;
    modelEl.value = config.provider.model;
    baseUrlEl.value = config.provider.baseUrl;
    apiKeyEl.value = config.provider.apiKey;
    temperatureEl.value = String(config.temperature);
    defaultStyleEl.value = config.defaultStyle;
    defaultModeEl.value = config.defaultMode;
    defaultPresentEl.value = config.defaultPresent;
    renderDomains();
  }
  function readFromForm() {
    const providerId = providerEl.value;
    const provider = {
      providerId,
      model: modelEl.value.trim() || defaultProvider(providerId).model,
      baseUrl: baseUrlEl.value.trim() || defaultProvider(providerId).baseUrl,
      apiKey: apiKeyEl.value.trim()
    };
    const temperature = Number(temperatureEl.value);
    return {
      ...config,
      provider,
      temperature: Number.isFinite(temperature) ? Math.min(1, Math.max(0, temperature)) : 0.2,
      defaultStyle: defaultStyleEl.value,
      defaultMode: defaultModeEl.value,
      defaultPresent: defaultPresentEl.value
    };
  }
  async function persist() {
    postUi(port, { type: "UI_SET_CONFIG", config });
  }
  function onBackgroundMessage(m) {
    if (m.type === "UI_CONFIG") {
      config = m.config;
      applyToForm();
    }
  }
  saveBtn.addEventListener("click", async () => {
    config = readFromForm();
    await persist();
    setText(saveStatusEl, "\u5DF2\u4FDD\u5B58");
    setTimeout(() => setText(saveStatusEl, ""), 1200);
  });
  resetBtn.addEventListener("click", async () => {
    config = defaultConfig();
    await persist();
    applyToForm();
    setText(saveStatusEl, "\u5DF2\u6062\u590D\u9ED8\u8BA4");
    setTimeout(() => setText(saveStatusEl, ""), 1200);
  });
  providerEl.addEventListener("change", () => {
    const providerId = providerEl.value;
    const defaults = defaultProvider(providerId);
    modelEl.value = defaults.model;
    baseUrlEl.value = defaults.baseUrl;
  });
  addDomainBtn.addEventListener("click", async () => {
    const d = normalizeDomain(autoDomainEl.value);
    if (!d) {
      setText(saveStatusEl, "\u57DF\u540D\u683C\u5F0F\u4E0D\u6B63\u786E");
      return;
    }
    if (config.auto.domains.includes(d)) {
      setText(saveStatusEl, "\u5DF2\u5B58\u5728");
      return;
    }
    const originPattern = `*://${d}/*`;
    const granted = await chrome.permissions.request({ origins: [originPattern] });
    if (!granted) {
      setText(saveStatusEl, "\u672A\u6388\u6743\uFF0C\u8BE5\u57DF\u540D\u4E0D\u4F1A\u81EA\u52A8\u8FD0\u884C");
      return;
    }
    config = {
      ...config,
      auto: {
        ...config.auto,
        enabled: true,
        domains: [...config.auto.domains, d]
      }
    };
    await persist();
    autoDomainEl.value = "";
    renderDomains();
    setText(saveStatusEl, "\u5DF2\u6DFB\u52A0\u5E76\u6388\u6743");
    setTimeout(() => setText(saveStatusEl, ""), 1200);
  });
})();
//# sourceMappingURL=options.js.map
